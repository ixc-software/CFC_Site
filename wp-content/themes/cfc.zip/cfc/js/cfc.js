
$(function(){
	
	$("[data-animate]").animate( { height: "show", opacity: "1" } , "500" );

	var
		$navigation = $( "#navigation" ),
		$viewport = $( "#viewport" ),
		$phoneapp = $( "#phoneapp" ),
		$content = $( "#content" ),
		$watchVisible = $( "[data-visible]" );
		
	$watchVisible.filter( "[data-visible='']" ).hide();
	$watchVisible.not( "[data-visible='']" ).show();
	
	if ( /^http:\/\/cfc.io\/$/.test( self.location.href.replace("#","") ) ) {
		$phoneapp.attr( "data-visible", "visible" );
	} else {
		$phoneapp.attr( "data-visible", "" );
	}

	$navigation.on( "menuleft" , function() {
		//$phoneapp.animate( { left:"45%" } , "fast" );
		//$phoneapp.animate( { right:"60px" } , "fast" );
	});
	
	$navigation.on( "menucenter" , function() {
		//$phoneapp.animate( { left:"61%" } , "fast" );
		//$phoneapp.animate( { right:"60px" } , "fast" );
	});

	$navigation.on( "menuright" , function() {
		//$phoneapp.animate( { left:"37%" } , "fast" );
		//$phoneapp.animate( { right:"60px" } , "fast" );
	});
	
	$navigation.children( "li" ).on( "click" , function() {
		//hide other dropdowns
		$navigation.children( "li" ).not( this ).each(function(){
			$(this).removeClass( "active" ).find( "ol" ).attr( "data-visible", "" ).slideUp( 100 );
		});
		//variables
		var
			action = $(this).data( "action" ),
			$dropdown = $(this).find( "ol" );
		//
		( !$dropdown.attr( "data-visible" ) ) ?
			$(this).find( "ol" ).animate( { height: "show", opacity: "1" } , "fast" )
			&& $navigation.trigger( action )
			&& $(this).addClass( "active" )
			&& $phoneapp.show()
			&& $content.animate( { height: "hide", opacity: "0" } , "fast" ).parent().removeClass( "__opened" )
			&& $dropdown.attr( "data-visible" , "visible" )
		:
			$(this).find( "ol" ).animate( { height: "hide", opacity: "0" } , "fast" )
			&& $dropdown.attr( "data-visible" , "" )
			&& $(this).removeClass( "active" )
			//&& $phoneapp.animate( { right:"41%" } , "fast" )
			&& ( !/^http:\/\/cfc.io\/$/.test( self.location.href.replace("#","") ) )?$phoneapp.hide()
				&& $content.animate( { height: "show", opacity: "1" } , "fast" ).parent().addClass( "__opened" ):"";
	});
	
	$navigation.children( "li" ).children(  "a" ).on( "click" , function(e) { e.preventDefault(); })
	$navigation.find( "ol" ).on( "click" , function(e) { e.stopPropagation(); })
	
	$("body").css({"backgroundImage":"url(http://192.168.6.92/cfc//wp-content/themes/cfc/images/background.jpg)","backgroundPosition":"center top", "backgroundRepeat":"no-repeat","backgroundAttachment":"fixed","backgroundColor":"black"});
	
	var centeringPhone = function() {
		$phoneapp.css( "top" , ($viewport.innerHeight()/2|0)-($phoneapp.outerHeight()/2|0)+ "px" );
	};
	centeringPhone.call();
	
	$("window").add( "body" ).on( "resize", centeringPhone );
	
	//fixing height of two-row submenu's
	$navigation.children( "li" ).find( "li" ).find( "a" ).each(function(){
		if ( $(this).text().length > 12 )
			$(this).addClass( "two-rows" );
	})
	
})//d-r
